export { default as WalletInfo } from './WalletInfo';
